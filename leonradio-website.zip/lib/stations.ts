export const stationsConfig = {
  mixfm: {
    id: "mixfm",
    name: "MixFM",
    genre: "Pop",
    description: "The hottest pop hits and chart-toppers, 24/7",
    color: "#0284c7", // blue-600
    bgClass: "bg-blue-600",
    streamUrl: "https://azura.typicalmedia.net/listen/mixfm/radio.mp3",
    apiUrl: "https://azura.typicalmedia.net/api/nowplaying/mixfm",
    logoUrl: "https://itsdefnotleon.neocities.org/image-removebg-preview%20(1).png",
    backgroundUrl: "https://itsdefnotleon.neocities.org/Untitled%20design%20(6).png",
  },
  "mixfm-fresh": {
    id: "mixfm-fresh",
    name: "MixFM Fresh",
    genre: "Fresh Hits",
    description: "The newest releases and fresh discoveries",
    color: "#86efac", // green-300
    bgClass: "bg-green-300",
    streamUrl: "https://azura.typicalmedia.net/listen/fresh/radio.mp3",
    apiUrl: "https://azura.typicalmedia.net/api/nowplaying/fresh",
    logoUrl: "https://itsdefnotleon.neocities.org/Untitled%20design%20(23)%20(1).png",
    backgroundUrl: "https://framerusercontent.com/images/byJQ5rcsaGGvKgvhii2X9tgKW4.png",
  },
  "power-hit": {
    id: "power-hit",
    name: "Power Hit Radio",
    genre: "Hits",
    description: "Powerful hits that rock your world",
    color: "#dc2626", // red-600
    bgClass: "bg-red-600",
    streamUrl: "https://cdnstream1.typicalmedia.net/powerhits",
    apiUrl: "https://azura.typicalmedia.net/api/nowplaying/powerhitradio",
    logoUrl: "https://framerusercontent.com/images/wxVwutZaQjcsPdIrE8bm3EjAB0.png?scale-down-to=512",
    backgroundUrl: "https://itsdefnotleon.neocities.org/Untitled%20design%20(7).png",
  },
  trendy: {
    id: "trendy",
    name: "Trendy Radio",
    genre: "Trending",
    description: "What's trending now in music",
    color: "#22c55e", // green-500
    bgClass: "bg-green-500",
    streamUrl: "https://cdnstream1.typicalmedia.net/trendy",
    apiUrl: "https://azura.typicalmedia.net/api/nowplaying/trendy",
    logoUrl: "https://itsdefnotleon.neocities.org/image__1_-removebg-preview.png",
    backgroundUrl: "https://itsdefnotleon.neocities.org/Sonic_cleanup%20(1).jpg",
  },
}

export type StationId = keyof typeof stationsConfig
