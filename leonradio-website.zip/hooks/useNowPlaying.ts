"use client"

import { useState, useEffect } from "react"

interface NowPlayingData {
  station: {
    name: string
    description?: string
    listen_url: string
  }
  now_playing: {
    song: {
      title: string
      artist: string
      album?: string
      art?: string
    }
    elapsed: number
    duration: number
  }
  song_history: Array<{
    song: {
      title: string
      artist: string
      album?: string
    }
    played_at: number
  }>
  listeners: {
    total: number
  }
}

export function useNowPlaying(apiUrl: string, enabled = true) {
  const [data, setData] = useState<NowPlayingData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!enabled || !apiUrl) return

    const fetchNowPlaying = async () => {
      try {
        setLoading(true)
        setError(null)

        const response = await fetch(apiUrl, {
          method: "GET",
          headers: {
            Accept: "application/json",
          },
        })

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const result = await response.json()
        setData(result)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to fetch now playing data")
        console.error("Error fetching now playing:", err)
      } finally {
        setLoading(false)
      }
    }

    // Initial fetch
    fetchNowPlaying()

    // Set up polling every 30 seconds
    const interval = setInterval(fetchNowPlaying, 30000)

    return () => clearInterval(interval)
  }, [apiUrl, enabled])

  return { data, loading, error }
}
