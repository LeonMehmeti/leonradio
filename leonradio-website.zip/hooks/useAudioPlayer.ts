"use client"

import { useState, useRef, useEffect } from "react"

export function useAudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStation, setCurrentStation] = useState<string | null>(null)
  const [volume, setVolume] = useState(0.7)
  const [isLoading, setIsLoading] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Create audio element
    audioRef.current = new Audio()
    audioRef.current.volume = volume
    audioRef.current.preload = "none"

    const audio = audioRef.current

    const handleLoadStart = () => setIsLoading(true)
    const handleCanPlay = () => setIsLoading(false)
    const handleError = () => {
      setIsLoading(false)
      setIsPlaying(false)
      console.error("Audio playback error")
    }

    audio.addEventListener("loadstart", handleLoadStart)
    audio.addEventListener("canplay", handleCanPlay)
    audio.addEventListener("error", handleError)

    return () => {
      audio.removeEventListener("loadstart", handleLoadStart)
      audio.removeEventListener("canplay", handleCanPlay)
      audio.removeEventListener("error", handleError)
      audio.pause()
      audio.src = ""
    }
  }, [])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  const playStation = async (stationId: string, streamUrl: string) => {
    if (!audioRef.current) return

    try {
      // If same station is playing, just pause/unpause
      if (currentStation === stationId && isPlaying) {
        audioRef.current.pause()
        setIsPlaying(false)
        return
      }

      // Stop current stream
      audioRef.current.pause()
      audioRef.current.src = ""

      // Start new stream
      setCurrentStation(stationId)
      setIsLoading(true)
      audioRef.current.src = streamUrl

      await audioRef.current.play()
      setIsPlaying(true)
    } catch (error) {
      console.error("Failed to play audio:", error)
      setIsPlaying(false)
      setIsLoading(false)
    }
  }

  const stopPlayback = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.src = ""
    }
    setIsPlaying(false)
    setCurrentStation(null)
    setIsLoading(false)
  }

  return {
    isPlaying,
    currentStation,
    volume,
    isLoading,
    playStation,
    stopPlayback,
    setVolume,
  }
}
