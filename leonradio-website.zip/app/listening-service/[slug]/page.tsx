"use client"

import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  User,
  Radio,
  Play,
  Smartphone,
  Headphones,
  Heart,
  Settings,
  Music,
  Globe,
  Zap,
  ArrowLeft,
  Home,
  Mic,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import { StickyPlayer } from "@/components/sticky-player"

const articles = [
  {
    id: "getting-started",
    title: "Getting Started with LeonRadio",
    category: "Basics",
    readTime: "3 min read",
    description: "Learn the fundamentals of using LeonRadio and discover all our amazing features.",
    icon: <Radio className="h-6 w-6" />,
    content: [
      {
        heading: "Welcome to LeonRadio",
        text: "LeonRadio is your ultimate destination for high-quality music streaming across multiple radio stations. Whether you're looking for the latest pop hits, fresh discoveries, or trending music, we have something for everyone.",
      },
      {
        heading: "Our Stations",
        text: "We operate four distinct radio stations: MixFM (pop hits), MixFM Fresh (new releases), Power Hit Radio (rock & alternative), and Trendy Radio (electronic & dance). Each station has its own unique personality and carefully curated playlists.",
      },
      {
        heading: "Quick Start Guide",
        text: "Simply visit our homepage, choose your favorite station, and click the play button. It's that easy! You can switch between stations at any time using our station selector or visit individual station pages for more detailed information.",
      },
    ],
  },
  {
    id: "how-to-listen",
    title: "How to Listen to Our Stations",
    category: "Listening",
    readTime: "4 min read",
    description: "Step-by-step guide on how to tune in and enjoy our radio stations.",
    icon: <Play className="h-6 w-6" />,
    content: [
      {
        heading: "Starting Your Listening Experience",
        text: "To start listening, navigate to any of our station pages or use the quick play buttons on the homepage. Click the red play button to begin streaming. The audio will start automatically once the connection is established.",
      },
      {
        heading: "Station Navigation",
        text: "Use the top navigation menu to browse between different stations. Each station page shows the current song, recently played tracks, and upcoming shows. You can also see how many people are currently listening.",
      },
      {
        heading: "Player Controls",
        text: "Our player features easy-to-use controls including play/pause, volume adjustment, and station switching. The mini player at the top of the page allows you to control playback while browsing other parts of the site.",
      },
      {
        heading: "Mobile Experience",
        text: "On mobile devices, tap any station to start listening. The mobile player provides a full-screen experience with large album artwork and easy-to-tap controls optimized for touch interaction.",
      },
    ],
  },
  {
    id: "mobile-app-guide",
    title: "Mobile App Features",
    category: "Mobile",
    readTime: "5 min read",
    description: "Discover all the features available in our mobile-optimized experience.",
    icon: <Smartphone className="h-6 w-6" />,
    content: [
      {
        heading: "Mobile-First Design",
        text: "Our mobile experience is designed from the ground up to provide the best possible listening experience on your phone or tablet. The interface adapts perfectly to different screen sizes and orientations.",
      },
      {
        heading: "Full-Screen Player",
        text: "Tap the mini player at the bottom of your screen to open the full-screen mobile player. This immersive view shows large album artwork, song information, and easy-to-use playback controls.",
      },
      {
        heading: "Bottom Navigation",
        text: "Navigate between Home, Channels, Podcasts, and Settings using the bottom navigation bar. This keeps all important features within easy reach of your thumb.",
      },
      {
        heading: "Continue Listening",
        text: "The home screen shows your recently played stations in the 'Continue Listening' section, making it easy to jump back to your favorite content.",
      },
    ],
  },
  {
    id: "audio-quality",
    title: "Audio Quality & Technical Requirements",
    category: "Technical",
    readTime: "3 min read",
    description: "Learn about our audio quality standards and what you need for the best experience.",
    icon: <Headphones className="h-6 w-6" />,
    content: [
      {
        heading: "High-Quality Streaming",
        text: "All our stations stream in high-quality MP3 format at 128kbps, providing excellent sound quality while maintaining reasonable bandwidth usage. This ensures smooth playback even on slower internet connections.",
      },
      {
        heading: "Internet Requirements",
        text: "For optimal streaming, we recommend a stable internet connection with at least 256kbps bandwidth. Both WiFi and mobile data connections are supported.",
      },
      {
        heading: "Browser Compatibility",
        text: "LeonRadio works on all modern web browsers including Chrome, Firefox, Safari, and Edge. No additional plugins or downloads are required - just visit our website and start listening.",
      },
      {
        heading: "Troubleshooting Audio Issues",
        text: "If you experience audio problems, try refreshing the page, checking your internet connection, or switching to a different browser. Make sure your device's volume is turned up and not muted.",
      },
    ],
  },
  {
    id: "station-features",
    title: "Station Features & Information",
    category: "Features",
    readTime: "4 min read",
    description: "Explore the unique features available on each of our radio stations.",
    icon: <Music className="h-6 w-6" />,
    content: [
      {
        heading: "Live Now Playing Information",
        text: "Each station displays real-time information about the currently playing song, including track title, artist name, and album artwork when available. This information updates automatically as songs change.",
      },
      {
        heading: "Recently Played History",
        text: "View the last 10 songs played on each station with timestamps. This helps you discover new music and find songs you heard earlier but missed the title of.",
      },
      {
        heading: "Listener Count",
        text: "See how many people are currently tuned in to each station. This gives you an idea of what's popular and trending among our community.",
      },
      {
        heading: "Station Schedules",
        text: "Each station runs 24/7 with carefully curated playlists. Special shows and events are announced on our social media channels and website updates.",
      },
    ],
  },
  {
    id: "personalization",
    title: "Personalizing Your Experience",
    category: "Customization",
    readTime: "3 min read",
    description: "Learn how to customize LeonRadio to match your preferences.",
    icon: <Heart className="h-6 w-6" />,
    content: [
      {
        heading: "Favorite Stations",
        text: "While we don't currently have user accounts, you can bookmark your favorite station pages in your browser for quick access. Each station has its own unique URL that you can save.",
      },
      {
        heading: "Volume Control",
        text: "Adjust the volume using the volume controls in our player or your device's system volume. The player remembers your volume preference during your session.",
      },
      {
        heading: "Station Recommendations",
        text: "Based on listening patterns, we recommend trying different stations. If you like MixFM, you might enjoy MixFM Fresh for newer releases, or Power Hit Radio for more energetic tracks.",
      },
      {
        heading: "Sharing Music",
        text: "Found a song you love? Share the station with friends using your browser's share function or by copying the station URL. Help others discover great music!",
      },
    ],
  },
  {
    id: "troubleshooting",
    title: "Troubleshooting Common Issues",
    category: "Support",
    readTime: "5 min read",
    description: "Solutions to common problems and how to get help when you need it.",
    icon: <Settings className="h-6 w-6" />,
    content: [
      {
        heading: "Playback Issues",
        text: "If audio doesn't start or stops unexpectedly, first check your internet connection. Try refreshing the page or switching to a different browser. Clear your browser cache if problems persist.",
      },
      {
        heading: "Mobile Player Problems",
        text: "On mobile devices, ensure you're not in silent mode and that media volume is turned up. Some browsers require user interaction before playing audio, so make sure to tap the play button.",
      },
      {
        heading: "Slow Loading",
        text: "If the website loads slowly, check your internet speed. Try closing other applications that might be using bandwidth. Consider switching from mobile data to WiFi for better performance.",
      },
      {
        heading: "Getting Help",
        text: "If you continue experiencing issues, visit our About page for contact information. We're here to help ensure you have the best possible listening experience.",
      },
    ],
  },
  {
    id: "whats-new",
    title: "What's New & Updates",
    category: "Updates",
    readTime: "2 min read",
    description: "Stay up to date with the latest features and improvements to LeonRadio.",
    icon: <Zap className="h-6 w-6" />,
    content: [
      {
        heading: "Recent Updates",
        text: "We're constantly improving LeonRadio with new features and enhancements. Recent updates include improved mobile experience, better audio quality, and enhanced station information display.",
      },
      {
        heading: "Mobile Player Enhancement",
        text: "Our new mobile player provides a full-screen listening experience with large album artwork, intuitive controls, and seamless navigation between stations.",
      },
      {
        heading: "Performance Improvements",
        text: "We've optimized our streaming infrastructure to provide faster loading times and more reliable connections across all devices and network conditions.",
      },
      {
        heading: "Coming Soon",
        text: "We're working on exciting new features including personalized recommendations, social sharing capabilities, and enhanced discovery tools to help you find new music you'll love.",
      },
    ],
  },
]

export default function ArticlePage() {
  const params = useParams()
  const slug = params.slug as string

  const article = articles.find((a) => a.id === slug)

  if (!article) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Article Not Found</h1>
          <Link href="/listening-service">
            <Button>Back to Listening Service</Button>
          </Link>
        </div>
      </div>
    )
  }

  const relatedArticles = articles.filter((a) => a.id !== slug && a.category === article.category).slice(0, 3)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Sticky Player */}
      <StickyPlayer />

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg mt-16">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center space-x-3">
                <div className="bg-white/20 p-2 rounded-lg">
                  <Radio className="h-8 w-8" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">LeonRadio</h1>
                  <p className="text-blue-100 text-sm">Your Music, Your Way</p>
                </div>
              </Link>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/stations" className="hover:text-blue-200 transition-colors">
                Radio Stations
              </Link>
              <Link href="/about" className="hover:text-blue-200 transition-colors">
                About
              </Link>
              <Link href="/listening-service" className="text-blue-200 font-semibold">
                Listening Service
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search stations..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
              </div>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Layout */}
      <div className="md:hidden">
        <div className="bg-gray-900 text-white min-h-screen pb-20">
          {/* Header */}
          <div className="p-4">
            <Link href="/listening-service" className="flex items-center space-x-2 text-gray-400 mb-4">
              <ArrowLeft className="h-5 w-5" />
              <span>Back to Listening Service</span>
            </Link>

            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">{article.icon}</div>
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <Badge variant="secondary" className="text-xs">
                    {article.category}
                  </Badge>
                  <span className="text-xs text-gray-400">{article.readTime}</span>
                </div>
                <h1 className="text-xl font-bold">{article.title}</h1>
              </div>
            </div>

            <p className="text-gray-400 text-sm">{article.description}</p>
          </div>

          {/* Content */}
          <div className="p-4 space-y-6">
            {article.content.map((section, index) => (
              <div key={index}>
                <h2 className="text-lg font-bold text-white mb-3">{section.heading}</h2>
                <p className="text-gray-300 leading-relaxed">{section.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-700">
          <div className="flex justify-around py-2">
            <Link href="/" className="flex flex-col items-center py-2 px-4">
              <Home className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Home</span>
            </Link>
            <Link href="/stations" className="flex flex-col items-center py-2 px-4">
              <Radio className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Channels</span>
            </Link>
            <button className="flex flex-col items-center py-2 px-4">
              <Mic className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Podcasts</span>
            </Link>
            <Link href="/about" className="flex flex-col items-center py-2 px-4">
              <Settings className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Settings</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden md:block">
        <main className="container mx-auto px-4 py-12">
          {/* Breadcrumb */}
          <div className="flex items-center space-x-2 text-sm text-gray-600 mb-8">
            <Link href="/listening-service" className="hover:text-blue-600">
              Listening Service
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="text-gray-800">{article.title}</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">
              <Card className="mb-8">
                <CardContent className="p-8">
                  {/* Article Header */}
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="bg-blue-100 p-3 rounded-lg">{article.icon}</div>
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <Badge variant="secondary">{article.category}</Badge>
                        <span className="text-sm text-gray-500">{article.readTime}</span>
                      </div>
                      <h1 className="text-3xl font-bold text-gray-800">{article.title}</h1>
                    </div>
                  </div>

                  <p className="text-lg text-gray-600 mb-8 leading-relaxed">{article.description}</p>

                  {/* Article Content */}
                  <div className="prose prose-lg max-w-none">
                    {article.content.map((section, index) => (
                      <div key={index} className="mb-8">
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">{section.heading}</h2>
                        <p className="text-gray-600 leading-relaxed">{section.text}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Related Articles */}
              {relatedArticles.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Related Articles</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {relatedArticles.map((relatedArticle) => (
                      <Link key={relatedArticle.id} href={`/listening-service/${relatedArticle.id}`}>
                        <Card className="h-full hover:shadow-lg transition-all duration-300 cursor-pointer group">
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-3">
                              <div className="bg-blue-100 p-2 rounded-lg group-hover:bg-blue-200 transition-colors">
                                {relatedArticle.icon}
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {relatedArticle.category}
                              </Badge>
                            </div>
                            <h3 className="font-semibold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
                              {relatedArticle.title}
                            </h3>
                            <p className="text-sm text-gray-600 line-clamp-2">{relatedArticle.description}</p>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <Link href="/stations">
                      <Button variant="outline" className="w-full justify-start">
                        <Radio className="h-4 w-4 mr-2" />
                        Browse Stations
                      </Button>
                    </Link>
                    <Link href="/about">
                      <Button variant="outline" className="w-full justify-start">
                        <Globe className="h-4 w-4 mr-2" />
                        About LeonRadio
                      </Button>
                    </Link>
                    <Link href="/listening-service">
                      <Button variant="outline" className="w-full justify-start">
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        All Articles
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-gray-800 text-white py-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <Radio className="h-6 w-6" />
                  <span className="text-xl font-bold">LeonRadio</span>
                </div>
                <p className="text-gray-400">
                  Your ultimate destination for high-quality music streaming. Listen to the best music 24/7.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Quick Links</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/stations" className="hover:text-white transition-colors">
                      Radio Stations
                    </Link>
                  </li>
                  <li>
                    <Link href="/about" className="hover:text-white transition-colors">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/listening-service" className="hover:text-white transition-colors">
                      Listening Service
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Support</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Help Center
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Contact Us
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Technical Support
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2024 LeonRadio. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
