"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Radio, Search, User, Music, Users, Target, Heart, Mail, Phone, MapPin } from "lucide-react"
import Link from "next/link"
import { stationsConfig } from "@/lib/stations"
import { StickyPlayer } from "@/components/sticky-player"

export default function AboutPage() {
  const stations = Object.values(stationsConfig)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Sticky Player */}
      <StickyPlayer />

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg mt-16">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center space-x-3">
                <div className="bg-white/20 p-2 rounded-lg">
                  <Radio className="h-8 w-8" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">LeonRadio</h1>
                  <p className="text-blue-100 text-sm">Your Music, Your Way</p>
                </div>
              </Link>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/stations" className="hover:text-blue-200 transition-colors">
                Radio Stations
              </Link>
              <Link href="/about" className="text-blue-200 font-semibold">
                About
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search stations..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
              </div>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-900 to-black text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="bg-white/10 w-32 h-32 mx-auto rounded-full flex items-center justify-center mb-8">
            <Radio className="h-16 w-16" />
          </div>
          <h1 className="text-5xl font-bold mb-4">About LeonRadio</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Broadcasting the best music across multiple stations, bringing you the soundtrack to your life with
            carefully curated playlists and the latest hits.
          </p>
        </div>
      </section>

      <main className="container mx-auto px-4 py-12">
        {/* Mission Section */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-8">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Our Mission</h3>
                <p className="text-gray-600">
                  To provide high-quality music streaming across diverse genres, connecting listeners with the music
                  they love and discovering new favorites.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Our Community</h3>
                <p className="text-gray-600">
                  Building a vibrant community of music lovers who share their passion for discovering and enjoying
                  great music together.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Our Passion</h3>
                <p className="text-gray-600">
                  Music is our passion. We carefully curate every playlist and ensure the highest quality streaming
                  experience for our listeners.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* About LeonRadio */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">The LeonRadio Story</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  LeonRadio was founded with a simple vision: to create a radio network that truly understands music
                  lovers. We believe that great music has the power to bring people together, inspire creativity, and
                  soundtrack life's most important moments.
                </p>
                <p>
                  Our network operates four distinct stations, each with its own personality and carefully curated music
                  selection. From the latest pop hits to fresh discoveries, from powerful rock anthems to trending
                  electronic beats, we have something for every musical taste.
                </p>
                <p>
                  What sets us apart is our commitment to quality and our understanding that music is personal. Our team
                  of music enthusiasts works around the clock to ensure that every song we play meets our high standards
                  and resonates with our listeners.
                </p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">By the Numbers</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold">4</div>
                  <div className="text-blue-100">Radio Stations</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">24/7</div>
                  <div className="text-blue-100">Live Streaming</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">1000+</div>
                  <div className="text-blue-100">Songs Daily</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">∞</div>
                  <div className="text-blue-100">Music Love</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Stations */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-800 text-center mb-12">Our Stations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {stations.map((station) => (
              <Card key={station.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className={`${station.color} h-32 relative flex items-center justify-center`}>
                    {station.logoUrl ? (
                      <img
                        src={station.logoUrl || "/placeholder.svg"}
                        alt={`${station.name} logo`}
                        className="h-16 w-auto object-contain"
                        onError={(e) => {
                          e.currentTarget.style.display = "none"
                          e.currentTarget.nextElementSibling?.classList.remove("hidden")
                        }}
                      />
                    ) : (
                      <Music className="h-12 w-12 text-white" />
                    )}
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-gray-800">{station.name}</h3>
                      <Badge variant="outline">{station.genre}</Badge>
                    </div>
                    <p className="text-gray-600 mb-4">{station.description}</p>
                    <Link href={`/station/${station.id}`}>
                      <Button className="w-full">Listen Now</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-800 text-center mb-12">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-8">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">L</span>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">Leon</h3>
                <p className="text-gray-600 mb-2">Founder & CEO</p>
                <p className="text-sm text-gray-500">
                  Visionary behind LeonRadio, passionate about bringing great music to the world.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-teal-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Music className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">Music Team</h3>
                <p className="text-gray-600 mb-2">Curators & DJs</p>
                <p className="text-sm text-gray-500">
                  Our talented team of music experts who carefully select every track we play.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-orange-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Radio className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">Tech Team</h3>
                <p className="text-gray-600 mb-2">Engineers & Developers</p>
                <p className="text-sm text-gray-500">
                  The technical wizards who keep our streams running smoothly 24/7.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
                <p className="text-blue-100 mb-6">
                  Have questions, suggestions, or just want to say hello? We'd love to hear from you!
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-200" />
                    <span>hello@leonradio.com</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-blue-200" />
                    <span>+1 (555) 123-LEON</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-blue-200" />
                    <span>Music City, Worldwide</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Quick Links</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Link href="/" className="hover:text-blue-200 transition-colors">
                    Home
                  </Link>
                  <Link href="/station/mixfm" className="hover:text-blue-200 transition-colors">
                    MixFM
                  </Link>
                  <Link href="/station/mixfm-fresh" className="hover:text-blue-200 transition-colors">
                    MixFM Fresh
                  </Link>
                  <Link href="/station/power-hit" className="hover:text-blue-200 transition-colors">
                    Power Hit Radio
                  </Link>
                  <Link href="/station/trendy" className="hover:text-blue-200 transition-colors">
                    Trendy Radio
                  </Link>
                  <a href="#" className="hover:text-blue-200 transition-colors">
                    Support
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Radio className="h-6 w-6" />
                <span className="text-xl font-bold">LeonRadio</span>
              </div>
              <p className="text-gray-400">
                Broadcasting the best music across multiple stations. Your soundtrack to life.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Our Stations</h4>
              <ul className="space-y-2 text-gray-400">
                <li>MixFM - Top 40 Hits</li>
                <li>MixFM Fresh - Latest Releases</li>
                <li>Power Hit Radio - Rock & Alternative</li>
                <li>Trendy Radio - Electronic & Dance</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Advertise
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Support
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 LeonRadio. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
