"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Play, Search, User, Loader2, Home, Radio, Mic, Settings, Music, Pause } from "lucide-react"
import Link from "next/link"
import { useAudioPlayer } from "@/hooks/useAudioPlayer"
import { stationsConfig } from "@/lib/stations"
import { MobilePlayer } from "@/components/mobile-player"

interface StationNowPlaying {
  id: string
  data: any
  loading: boolean
  error: string | null
}

export default function StationsPage() {
  const { isPlaying, currentStation, playStation, stopPlayback } = useAudioPlayer()
  const [stationsNowPlaying, setStationsNowPlaying] = useState<Record<string, StationNowPlaying>>({})
  const [isMobilePlayerOpen, setIsMobilePlayerOpen] = useState(false)

  const stations = Object.values(stationsConfig)

  useEffect(() => {
    // Initialize stationsNowPlaying with loading state
    const initialState: Record<string, StationNowPlaying> = {}
    stations.forEach((station) => {
      initialState[station.id] = {
        id: station.id,
        data: null,
        loading: true,
        error: null,
      }
    })
    setStationsNowPlaying(initialState)

    // Fetch now playing data for each station
    const fetchAllStationsData = async () => {
      const fetchPromises = stations.map(async (station) => {
        try {
          const response = await fetch(station.apiUrl)
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
          }
          const data = await response.json()
          return { id: station.id, data, loading: false, error: null }
        } catch (error) {
          console.error(`Error fetching data for ${station.id}:`, error)
          return {
            id: station.id,
            data: null,
            loading: false,
            error: error instanceof Error ? error.message : "Failed to fetch",
          }
        }
      })

      const results = await Promise.all(fetchPromises)
      const newState: Record<string, StationNowPlaying> = {}
      results.forEach((result) => {
        newState[result.id] = result
      })
      setStationsNowPlaying(newState)
    }

    fetchAllStationsData()

    // Set up polling every 30 seconds
    const interval = setInterval(() => {
      fetchAllStationsData()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const togglePlay = (stationId: string) => {
    const station = stationsConfig[stationId as keyof typeof stationsConfig]
    if (station) {
      if (currentStation === stationId && isPlaying) {
        stopPlayback()
      } else {
        playStation(stationId, station.streamUrl)
      }
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Desktop Header - Hidden on Mobile */}
      <header className="bg-transparent absolute top-16 left-0 right-0 z-40 hidden md:block">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <Link href="/" className="flex items-center space-x-2">
                <img
                  src="/leonradio-logo.png"
                  alt="LeonRadio"
                  className="h-10 w-auto object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
                <span className="text-xl font-bold text-white hidden">LeonRadio</span>
              </Link>

              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/stations" className="text-white font-medium">
                  Radio Stations
                </Link>
                <Link href="/about" className="text-white/80 hover:text-white font-medium">
                  About
                </Link>
                <a href="#" className="text-white/80 hover:text-white font-medium">
                  Contact
                </a>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
              </div>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Layout */}
      <div className="md:hidden">
        {/* Mobile Channels Page */}
        <div className="bg-gray-900 text-white min-h-screen pb-20">
          {/* Header */}
          <div className="p-4 text-center">
            <h1 className="text-2xl font-bold">Channels</h1>
          </div>

          {/* Stations Grid */}
          <div className="p-4">
            <div className="grid grid-cols-2 gap-4">
              {stations.map((station) => {
                const stationData = stationsNowPlaying[station.id]
                const nowPlaying = stationData?.data?.now_playing
                const isCurrentlyPlaying = currentStation === station.id && isPlaying

                return (
                  <div key={station.id} className="group">
                    {/* Station Card */}
                    <Link href={`/station/${station.id}`}>
                      <div
                        className="aspect-square rounded-lg overflow-hidden shadow-lg transition-all duration-300 cursor-pointer relative"
                        style={{ backgroundColor: station.color }}
                      >
                        {/* Station Logo */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          {station.logoUrl ? (
                            <img
                              src={station.logoUrl || "/placeholder.svg"}
                              alt={`${station.name} logo`}
                              className="h-16 w-auto object-contain"
                              onError={(e) => {
                                e.currentTarget.style.display = "none"
                                e.currentTarget.nextElementSibling?.classList.remove("hidden")
                              }}
                            />
                          ) : (
                            <div className="text-white text-lg font-bold">{station.name}</div>
                          )}
                        </div>

                        {/* Live indicator */}
                        {isCurrentlyPlaying && (
                          <div className="absolute top-2 right-2">
                            <div className="bg-red-600 text-white px-2 py-1 rounded text-xs font-bold">LIVE</div>
                          </div>
                        )}
                      </div>
                    </Link>

                    {/* Station Info */}
                    <div className="mt-3">
                      <p className="text-xs text-gray-400 uppercase tracking-wide">{station.name}</p>
                      <h3 className="text-white font-bold text-sm">
                        {stationData?.loading ? "Loading..." : nowPlaying?.song?.title || "No song info"}
                      </h3>
                      <p className="text-gray-400 text-xs truncate">{nowPlaying?.song?.artist || ""}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Mobile Mini Player */}
        {isPlaying && currentStation && (
          <div
            className="fixed bottom-16 left-0 right-0 text-white p-4 flex items-center space-x-3 cursor-pointer z-40"
            style={{
              backgroundColor: stationsConfig[currentStation as keyof typeof stationsConfig]?.color || "#ef4444",
            }}
            onClick={() => setIsMobilePlayerOpen(true)}
          >
            <div className="w-12 h-12 rounded-lg overflow-hidden bg-black/20 flex items-center justify-center flex-shrink-0">
              {stationsNowPlaying[currentStation]?.data?.now_playing?.song?.art ? (
                <img
                  src={stationsNowPlaying[currentStation].data.now_playing.song.art || "/placeholder.svg"}
                  alt="Album cover"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
              ) : null}
              <Music
                className={`h-6 w-6 text-white ${stationsNowPlaying[currentStation]?.data?.now_playing?.song?.art ? "hidden" : ""}`}
              />
            </div>
            <div className="flex-grow min-w-0">
              <p className="font-bold text-sm">{stationsConfig[currentStation as keyof typeof stationsConfig]?.name}</p>
              <p className="text-white/80 text-xs truncate">
                {stationsNowPlaying[currentStation]?.data?.now_playing?.song?.title
                  ? `${stationsNowPlaying[currentStation].data.now_playing.song.title} - ${stationsNowPlaying[currentStation].data.now_playing.song.artist}`
                  : "Loading..."}
              </p>
            </div>
            <Button
              onClick={(e) => {
                e.stopPropagation()
                if (currentStation) {
                  togglePlay(currentStation)
                }
              }}
              className="bg-white/20 hover:bg-white/30 text-white border-none"
              size="icon"
            >
              <Pause className="h-5 w-5" />
            </Button>
          </div>
        )}

        {/* Mobile Player Modal */}
        <MobilePlayer
          isOpen={isMobilePlayerOpen}
          onClose={() => setIsMobilePlayerOpen(false)}
          nowPlayingData={stationsNowPlaying[currentStation || ""]?.data}
        />

        {/* Mobile Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-700">
          <div className="flex justify-around py-2">
            <Link href="/" className="flex flex-col items-center py-2 px-4">
              <Home className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Home</span>
            </Link>
            <Link href="/stations" className="flex flex-col items-center py-2 px-4">
              <Radio className="h-6 w-6 text-white" />
              <span className="text-xs text-white mt-1">Channels</span>
            </Link>
            <button className="flex flex-col items-center py-2 px-4">
              <Mic className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Podcasts</span>
            </button>
            <Link href="/about" className="flex flex-col items-center py-2 px-4">
              <Settings className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Settings</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden md:block">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-gray-900 to-black text-white py-24 mt-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-6xl md:text-8xl font-bold">Stations</h1>
          </div>
        </section>

        {/* Stations Grid */}
        <main className="bg-gray-50 py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-gray-900 mb-12">Choose your station</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {stations.map((station) => {
                const stationData = stationsNowPlaying[station.id]
                const nowPlaying = stationData?.data?.now_playing
                const isCurrentlyPlaying = currentStation === station.id && isPlaying

                return (
                  <div key={station.id} className="group">
                    {/* Station Card - Square with Solid Color */}
                    <div
                      className="relative aspect-square rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                      style={{ backgroundColor: station.color }}
                      onClick={() => togglePlay(station.id)}
                    >
                      {/* Station Logo */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        {station.logoUrl ? (
                          <img
                            src={station.logoUrl || "/placeholder.svg"}
                            alt={`${station.name} logo`}
                            className="h-20 w-auto object-contain"
                            onError={(e) => {
                              e.currentTarget.style.display = "none"
                              e.currentTarget.nextElementSibling?.classList.remove("hidden")
                            }}
                          />
                        ) : (
                          <div className="text-white text-2xl font-bold">{station.name}</div>
                        )}
                      </div>

                      {/* Play Button */}
                      <div className="absolute bottom-4 left-4">
                        <Button
                          onClick={(e) => {
                            e.stopPropagation()
                            togglePlay(station.id)
                          }}
                          className="bg-white/20 hover:bg-white/30 text-white border-none backdrop-blur-sm"
                          size="icon"
                        >
                          {isCurrentlyPlaying ? (
                            <div className="w-3 h-3 bg-white"></div>
                          ) : (
                            <Play className="h-5 w-5 ml-0.5" />
                          )}
                        </Button>
                      </div>

                      {/* Live indicator */}
                      {isCurrentlyPlaying && (
                        <div className="absolute top-4 right-4">
                          <div className="bg-red-600 text-white px-2 py-1 rounded text-xs font-bold">LIVE</div>
                        </div>
                      )}
                    </div>

                    {/* Station Info */}
                    <div className="mt-4">
                      <Link href={`/station/${station.id}`}>
                        <h3 className="text-xl font-bold text-gray-900 hover:text-blue-600 transition-colors">
                          {station.name}
                        </h3>
                      </Link>

                      {/* Now Playing */}
                      {stationData?.loading ? (
                        <div className="flex items-center space-x-2 text-gray-400 mt-1">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          <span className="text-sm">Loading...</span>
                        </div>
                      ) : stationData?.error ? (
                        <p className="text-sm text-gray-500 mt-1">Unable to load song info</p>
                      ) : nowPlaying ? (
                        <div className="mt-1">
                          <p className="text-gray-900 font-medium">{nowPlaying.song.title}</p>
                          <p className="text-gray-600 text-sm">{nowPlaying.song.artist}</p>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500 mt-1">No song information available</p>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <img
                    src="/leonradio-logo.png"
                    alt="LeonRadio"
                    className="h-8 w-auto object-contain"
                    onError={(e) => {
                      e.currentTarget.style.display = "none"
                      e.currentTarget.nextElementSibling?.classList.remove("hidden")
                    }}
                  />
                  <span className="text-xl font-bold hidden">LeonRadio</span>
                </div>
                <p className="text-gray-400">
                  Your soundtrack to life. Broadcasting the best music across multiple stations.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Stations</h4>
                <ul className="space-y-2 text-gray-400">
                  {stations.map((station) => (
                    <li key={station.id}>
                      <Link href={`/station/${station.id}`} className="hover:text-white transition-colors">
                        {station.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Company</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/about" className="hover:text-white transition-colors">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Contact
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Careers
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Support</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Help Center
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Privacy Policy
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Terms of Service
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2024 LeonRadio. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
