"use client"
import { useParams } from "next/navigation"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import {
  Play,
  Pause,
  Music,
  Search,
  User,
  Loader2,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ThumbsUp,
  ThumbsDown,
  Home,
  Radio,
  Mic,
  Settings,
  MoreHorizontal,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useAudioPlayer } from "@/hooks/useAudioPlayer"
import { useNowPlaying } from "@/hooks/useNowPlaying"
import { stationsConfig, type StationId } from "@/lib/stations"
import { MobilePlayer } from "@/components/mobile-player"

export default function StationPage() {
  const params = useParams()
  const { isPlaying, currentStation, isLoading, playStation, stopPlayback } = useAudioPlayer()
  const [isExpanded, setIsExpanded] = useState(false)
  const [isMobilePlayerOpen, setIsMobilePlayerOpen] = useState(false)

  const slug = params.slug as string
  const station = stationsConfig[slug as StationId]

  const {
    data: nowPlayingData,
    loading: nowPlayingLoading,
    error: nowPlayingError,
  } = useNowPlaying(station?.apiUrl || "", !!station)

  if (!station) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Station Not Found</h1>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handlePlayToggle = () => {
    if (currentStation === station.id && isPlaying) {
      stopPlayback()
    } else {
      playStation(station.id, station.streamUrl)
    }
  }

  const isCurrentlyPlaying = currentStation === station.id && isPlaying
  const isCurrentlyLoading = currentStation === station.id && isLoading

  // Format timestamp to time
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp * 1000)
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    })
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Desktop Header - Hidden on Mobile */}
      <header className="bg-transparent absolute top-16 left-0 right-0 z-40 text-white hidden md:block">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <Link href="/" className="flex items-center space-x-2">
                <img
                  src="/leonradio-logo.png"
                  alt="LeonRadio"
                  className="h-10 w-auto object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
                <span className="text-xl font-bold text-white hidden">LeonRadio</span>
              </Link>

              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/stations" className="text-white/80 hover:text-white font-medium">
                  Radio Stations
                </Link>
                <Link href="/about" className="text-white/80 hover:text-white font-medium">
                  About
                </Link>
                <a href="#" className="text-white/80 hover:text-white font-medium">
                  Contact
                </a>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
              </div>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Layout */}
      <div className="md:hidden">
        {/* Mobile Station Page */}
        <div className="min-h-screen pb-32" style={{ backgroundColor: station.color }}>
          {/* Header */}
          <div className="flex items-center justify-between p-4 text-white">
            <Link href="/stations">
              <ChevronLeft className="h-6 w-6" />
            </Link>
            <div className="text-center">
              {station.logoUrl ? (
                <img
                  src={station.logoUrl || "/placeholder.svg"}
                  alt={`${station.name} logo`}
                  className="h-8 w-auto object-contain mx-auto"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
              ) : (
                <span className="font-bold">{station.name}</span>
              )}
            </div>
            <MoreHorizontal className="h-6 w-6" />
          </div>

          {/* Hero Image */}
          <div className="px-4 mb-6">
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black/20">
              {station.backgroundUrl ? (
                <img
                  src={station.backgroundUrl || "/placeholder.svg"}
                  alt={`${station.name} background`}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
              ) : (
                <div className="w-full h-full bg-gray-600 flex items-center justify-center">
                  <Music className="h-16 w-16 text-gray-400" />
                </div>
              )}
              <div className="absolute top-4 left-4">
                <div className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold">Live</div>
              </div>
            </div>
          </div>

          {/* Current Show Info */}
          <div className="px-4 mb-6">
            <p className="text-white/80 text-sm mb-1">00:00 - 23:59</p>
            <h1 className="text-white text-3xl font-bold mb-4">
              {station.id === "mixfm"
                ? "Best Music Right Now"
                : station.id === "power-hit"
                  ? "Hits Non Stop"
                  : station.name}
            </h1>

            {/* Play Button */}
            <div className="flex justify-end">
              <Button
                onClick={handlePlayToggle}
                disabled={isCurrentlyLoading}
                className="bg-red-600 hover:bg-red-700 text-white w-16 h-16 rounded-full"
                size="icon"
              >
                {isCurrentlyLoading ? (
                  <Loader2 className="h-8 w-8 animate-spin" />
                ) : isCurrentlyPlaying ? (
                  <Pause className="h-8 w-8" />
                ) : (
                  <Play className="h-8 w-8 ml-1" />
                )}
              </Button>
            </div>
          </div>

          {/* Live Section */}
          <div className="bg-gray-900 text-white rounded-t-3xl flex-1 min-h-96">
            <div className="p-4">
              <h2 className="text-2xl font-bold mb-6">Live</h2>

              {/* Current Song */}
              {nowPlayingData?.now_playing && (
                <div className="flex items-center space-x-4 mb-6 bg-gray-800 rounded-lg p-4">
                  <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-700 flex items-center justify-center flex-shrink-0">
                    {nowPlayingData.now_playing.song.art ? (
                      <img
                        src={nowPlayingData.now_playing.song.art || "/placeholder.svg"}
                        alt={`${nowPlayingData.now_playing.song.title} album cover`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = "none"
                          e.currentTarget.nextElementSibling?.classList.remove("hidden")
                        }}
                      />
                    ) : null}
                    <div
                      className={`w-full h-full rounded-lg flex items-center justify-center ${nowPlayingData.now_playing.song.art ? "hidden" : ""}`}
                      style={{ backgroundColor: station.color }}
                    >
                      <Music className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div className="flex-grow min-w-0">
                    <p className="text-red-500 text-sm font-bold mb-1">16:47</p>
                    <h3 className="text-white font-bold text-lg">{nowPlayingData.now_playing.song.title}</h3>
                    <p className="text-gray-400">{nowPlayingData.now_playing.song.artist}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button className="bg-gray-700 hover:bg-gray-600 text-white border-none" size="icon">
                      <ThumbsUp className="h-5 w-5" />
                    </Button>
                    <Button className="bg-gray-700 hover:bg-gray-600 text-white border-none" size="icon">
                      <ThumbsDown className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              )}

              {/* Recently Played */}
              <div className="space-y-4">
                {nowPlayingData?.song_history?.slice(0, 5).map((item, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-700 flex items-center justify-center flex-shrink-0">
                      {item.song.art ? (
                        <img
                          src={item.song.art || "/placeholder.svg"}
                          alt={`${item.song.title} album cover`}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = "none"
                            e.currentTarget.nextElementSibling?.classList.remove("hidden")
                          }}
                        />
                      ) : null}
                      <div
                        className={`w-full h-full bg-gray-600 rounded-lg flex items-center justify-center ${item.song.art ? "hidden" : ""}`}
                      >
                        <Music className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                    <div className="flex-grow min-w-0">
                      <p className="text-red-500 text-sm font-bold">{formatTime(item.played_at)}</p>
                      <h4 className="text-white font-bold">{item.song.title}</h4>
                      <p className="text-gray-400 text-sm">{item.song.artist}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button className="bg-gray-700 hover:bg-gray-600 text-white border-none" size="icon">
                        <ThumbsUp className="h-4 w-4" />
                      </Button>
                      <Button className="bg-gray-700 hover:bg-gray-600 text-white border-none" size="icon">
                        <ThumbsDown className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8 text-gray-500">
                    <p>No recent songs available</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Mini Player */}
        {isCurrentlyPlaying && (
          <div
            className="fixed bottom-16 left-0 right-0 bg-red-600 text-white p-4 flex items-center space-x-3 cursor-pointer"
            onClick={() => setIsMobilePlayerOpen(true)}
          >
            <div className="w-12 h-12 rounded-lg overflow-hidden bg-black/20 flex items-center justify-center flex-shrink-0">
              {nowPlayingData?.now_playing?.song?.art ? (
                <img
                  src={nowPlayingData.now_playing.song.art || "/placeholder.svg"}
                  alt="Album cover"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
              ) : null}
              <Music className={`h-6 w-6 text-white ${nowPlayingData?.now_playing?.song?.art ? "hidden" : ""}`} />
            </div>
            <div className="flex-grow min-w-0">
              <p className="font-bold text-sm">{station.name}</p>
              <p className="text-white/80 text-xs truncate">
                {nowPlayingData?.now_playing?.song?.title
                  ? `${nowPlayingData.now_playing.song.title} - ${nowPlayingData.now_playing.song.artist}`
                  : "Loading..."}
              </p>
            </div>
            <Button
              onClick={(e) => {
                e.stopPropagation()
                handlePlayToggle()
              }}
              className="bg-white/20 hover:bg-white/30 text-white border-none"
              size="icon"
            >
              <Pause className="h-5 w-5" />
            </Button>
          </div>
        )}

        {/* Mobile Player Modal */}
        <MobilePlayer
          isOpen={isMobilePlayerOpen}
          onClose={() => setIsMobilePlayerOpen(false)}
          nowPlayingData={nowPlayingData}
        />

        {/* Mobile Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-700">
          <div className="flex justify-around py-2">
            <Link href="/" className="flex flex-col items-center py-2 px-4">
              <Home className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Home</span>
            </Link>
            <Link href="/stations" className="flex flex-col items-center py-2 px-4">
              <Radio className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Channels</span>
            </Link>
            <button className="flex flex-col items-center py-2 px-4">
              <Mic className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Podcasts</span>
            </button>
            <Link href="/about" className="flex flex-col items-center py-2 px-4">
              <Settings className="h-6 w-6 text-gray-400" />
              <span className="text-xs text-gray-400 mt-1">Settings</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden md:block">
        {/* Hero Section with Station Card */}
        <section className="relative h-[70vh] overflow-hidden mt-16">
          {/* Background Image */}
          {station.backgroundUrl && (
            <div className="absolute inset-0">
              <img
                src={station.backgroundUrl || "/placeholder.svg"}
                alt={`${station.name} background`}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = "none"
                  e.currentTarget.parentElement?.classList.add("bg-gradient-to-br", "from-pink-500", "to-orange-500")
                }}
              />
            </div>
          )}

          {/* Fallback gradient background */}
          <div
            className={`absolute inset-0 ${!station.backgroundUrl ? "bg-gradient-to-br from-pink-500 to-orange-500" : ""}`}
          ></div>

          {/* Station Info Card - Centered Left */}
          <div className="absolute left-8 top-1/2 transform -translate-y-1/2 z-10">
            <Card className="w-80 overflow-hidden shadow-2xl transition-all duration-300 ease-in-out">
              <CardContent className="p-0">
                {/* Live Badge */}
                <div className="relative">
                  <Badge className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 text-xs font-bold z-10">
                    LIVE NOW
                  </Badge>

                  {/* Station Logo Section */}
                  <div
                    className={`${station.bgClass} h-48 flex items-center justify-center relative`}
                    style={{ backgroundColor: station.color }}
                  >
                    <div className="text-center text-white">
                      {station.logoUrl ? (
                        <img
                          src={station.logoUrl || "/placeholder.svg"}
                          alt={`${station.name} logo`}
                          className="h-20 w-auto mx-auto mb-2 object-contain"
                          onError={(e) => {
                            e.currentTarget.style.display = "none"
                            e.currentTarget.nextElementSibling?.classList.remove("hidden")
                          }}
                        />
                      ) : (
                        <Music className="h-16 w-16 mx-auto mb-2" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Station Name with Clickable Dropdown */}
                <button
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="w-full bg-black/20 backdrop-blur-sm p-4 flex items-center justify-between text-white hover:bg-black/30 transition-colors"
                >
                  <span className="font-bold text-lg">{station.name}</span>
                  {isExpanded ? (
                    <ChevronUp className="h-5 w-5 transition-transform duration-200" />
                  ) : (
                    <ChevronDown className="h-5 w-5 transition-transform duration-200" />
                  )}
                </button>

                {/* Expandable Description */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    isExpanded ? "max-h-32 opacity-100" : "max-h-0 opacity-0"
                  }`}
                >
                  <div className="bg-black/10 backdrop-blur-sm p-4 text-white">
                    <p className="text-sm leading-relaxed">{station.description}</p>
                    <div className="flex items-center space-x-4 mt-2 text-xs">
                      <span className="bg-white/20 px-2 py-1 rounded">{station.genre}</span>
                      {nowPlayingData && (
                        <span className="flex items-center">
                          <Music className="h-3 w-3 mr-1" />
                          {nowPlayingData.listeners.total} listeners
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Play Button */}
                <Button
                  onClick={handlePlayToggle}
                  disabled={isCurrentlyLoading}
                  className="w-full bg-pink-600 hover:bg-pink-700 text-white py-4 text-lg font-bold rounded-none"
                >
                  {isCurrentlyLoading ? (
                    <Loader2 className="h-6 w-6 mr-3 animate-spin" />
                  ) : isCurrentlyPlaying ? (
                    <Pause className="h-6 w-6 mr-3" />
                  ) : (
                    <Play className="h-6 w-6 mr-3" />
                  )}
                  {isCurrentlyLoading ? "LOADING..." : isCurrentlyPlaying ? "PAUSE LIVE" : "LISTEN LIVE"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Now Playing Section */}
        <main className="bg-gray-50 py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Now Playing</h2>

            {nowPlayingLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
              </div>
            ) : nowPlayingError ? (
              <div className="text-center py-12 text-gray-500">
                <p>Unable to load playlist information</p>
              </div>
            ) : nowPlayingData ? (
              <div className="bg-white rounded-lg shadow-sm">
                {/* Current Song */}
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-center space-x-4">
                    <div className="text-lg font-bold text-gray-900 w-16">NOW</div>
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center flex-shrink-0">
                      {nowPlayingData.now_playing.song.art ? (
                        <img
                          src={nowPlayingData.now_playing.song.art || "/placeholder.svg"}
                          alt={`${nowPlayingData.now_playing.song.title} album cover`}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = "none"
                            e.currentTarget.nextElementSibling?.classList.remove("hidden")
                          }}
                        />
                      ) : null}
                      <div
                        className={`w-full h-full rounded-lg flex items-center justify-center ${nowPlayingData.now_playing.song.art ? "hidden" : ""}`}
                        style={{ backgroundColor: station.color }}
                      >
                        <Music className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    <div className="flex-grow">
                      <h3 className="text-xl font-bold text-gray-900">{nowPlayingData.now_playing.song.title}</h3>
                      <p className="text-gray-600">{nowPlayingData.now_playing.song.artist}</p>
                    </div>
                  </div>
                </div>

                {/* Recently Played */}
                <div className="divide-y divide-gray-100">
                  {nowPlayingData.song_history?.slice(0, 10).map((item, index) => (
                    <div key={index} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="text-sm font-mono text-gray-500 w-16">{formatTime(item.played_at)}</div>
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center flex-shrink-0">
                          {item.song.art ? (
                            <img
                              src={item.song.art || "/placeholder.svg"}
                              alt={`${item.song.title} album cover`}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = "none"
                                e.currentTarget.nextElementSibling?.classList.remove("hidden")
                              }}
                            />
                          ) : null}
                          <div
                            className={`w-full h-full bg-gray-200 rounded-lg flex items-center justify-center ${item.song.art ? "hidden" : ""}`}
                          >
                            <Music className="h-6 w-6 text-gray-500" />
                          </div>
                        </div>
                        <div className="flex-grow">
                          <h4 className="font-bold text-gray-900">{item.song.title}</h4>
                          <p className="text-gray-600">{item.song.artist}</p>
                        </div>
                      </div>
                    </div>
                  )) || (
                    <div className="p-6 text-center text-gray-500">
                      <p>No recent songs available</p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <p>No playlist information available</p>
              </div>
            )}
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <img
                    src="/leonradio-logo.png"
                    alt="LeonRadio"
                    className="h-8 w-auto object-contain"
                    onError={(e) => {
                      e.currentTarget.style.display = "none"
                      e.currentTarget.nextElementSibling?.classList.remove("hidden")
                    }}
                  />
                  <span className="text-xl font-bold hidden">LeonRadio</span>
                </div>
                <p className="text-gray-400">
                  Your soundtrack to life. Broadcasting the best music across multiple stations.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Stations</h4>
                <ul className="space-y-2 text-gray-400">
                  {Object.values(stationsConfig).map((station) => (
                    <li key={station.id}>
                      <Link href={`/station/${station.id}`} className="hover:text-white transition-colors">
                        {station.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Company</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/about" className="hover:text-white transition-colors">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Contact
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Careers
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Support</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Help Center
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Privacy Policy
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-white transition-colors">
                      Terms of Service
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2024 LeonRadio. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
