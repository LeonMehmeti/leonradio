"use client"
import { Button } from "@/components/ui/button"
import { Play, Pause, ThumbsUp, ThumbsDown, ChevronDown, MoreHorizontal, Music } from "lucide-react"
import { useAudioPlayer } from "@/hooks/useAudioPlayer"
import { stationsConfig } from "@/lib/stations"

interface MobilePlayerProps {
  isOpen: boolean
  onClose: () => void
  nowPlayingData: any
}

export function MobilePlayer({ isOpen, onClose, nowPlayingData }: MobilePlayerProps) {
  const { isPlaying, currentStation, isLoading, playStation, stopPlayback } = useAudioPlayer()

  if (!isOpen || !currentStation) return null

  const station = stationsConfig[currentStation as keyof typeof stationsConfig]
  if (!station) return null

  const handlePlayToggle = () => {
    if (currentStation === station.id && isPlaying) {
      stopPlayback()
    } else {
      playStation(station.id, station.streamUrl)
    }
  }

  const showTitle =
    station.id === "mixfm" ? "Best Music Right Now" : station.id === "power-hit" ? "Hits Non Stop" : station.name

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      {/* Full Screen Player */}
      <div className="h-full" style={{ backgroundColor: station.color }}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 text-white">
          <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <ChevronDown className="h-6 w-6" />
          </Button>

          <div className="text-center">
            {station.logoUrl ? (
              <img
                src={station.logoUrl || "/placeholder.svg"}
                alt={`${station.name} logo`}
                className="h-8 w-auto object-contain mx-auto"
                onError={(e) => {
                  e.currentTarget.style.display = "none"
                  e.currentTarget.nextElementSibling?.classList.remove("hidden")
                }}
              />
            ) : (
              <span className="font-bold">{station.name}</span>
            )}
          </div>

          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <MoreHorizontal className="h-6 w-6" />
          </Button>
        </div>

        {/* Album Art */}
        <div className="px-8 mb-8 flex-1 flex items-center justify-center">
          <div className="w-80 h-80 max-w-full max-h-full rounded-3xl overflow-hidden bg-black/20 flex items-center justify-center">
            {nowPlayingData?.now_playing?.song?.art ? (
              <img
                src={nowPlayingData.now_playing.song.art || "/placeholder.svg"}
                alt="Album cover"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = "none"
                  e.currentTarget.nextElementSibling?.classList.remove("hidden")
                }}
              />
            ) : (
              <div className="w-full h-full bg-gray-600 flex items-center justify-center">
                <Music className="h-24 w-24 text-gray-400" />
              </div>
            )}
          </div>
        </div>

        {/* Song Info */}
        <div className="px-8 mb-8 text-center text-white">
          <p className="text-sm opacity-80 uppercase tracking-wider mb-2">{showTitle}</p>
          <h1 className="text-3xl font-bold mb-2">{nowPlayingData?.now_playing?.song?.title || "Loading..."}</h1>
          <p className="text-lg opacity-80">{nowPlayingData?.now_playing?.song?.artist || ""}</p>
        </div>

        {/* Controls */}
        <div className="px-8 mb-12">
          <div className="flex items-center justify-center space-x-8">
            {/* Thumbs Up */}
            <Button
              variant="ghost"
              size="icon"
              className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 text-white border-none"
            >
              <ThumbsUp className="h-6 w-6" />
            </Button>

            {/* Play/Pause */}
            <Button
              onClick={handlePlayToggle}
              disabled={isLoading}
              className="w-20 h-20 rounded-full bg-red-600 hover:bg-red-700 text-white border-none"
              size="icon"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : isPlaying ? (
                <Pause className="h-8 w-8" />
              ) : (
                <Play className="h-8 w-8 ml-1" />
              )}
            </Button>

            {/* Thumbs Down */}
            <Button
              variant="ghost"
              size="icon"
              className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 text-white border-none"
            >
              <ThumbsDown className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Bottom Navigation Icons */}
        <div className="px-8 pb-8">
          <div className="flex justify-center space-x-12">
            <Button variant="ghost" size="icon" className="text-white/60 hover:bg-white/10">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
            </Button>

            <Button variant="ghost" size="icon" className="text-white/60 hover:bg-white/10">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"
                />
              </svg>
            </Button>

            <Button variant="ghost" size="icon" className="text-white/60 hover:bg-white/10">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                />
              </svg>
            </Button>
          </div>
        </div>

        {/* Home Indicator */}
        <div className="flex justify-center pb-2">
          <div className="w-32 h-1 bg-white/30 rounded-full"></div>
        </div>
      </div>
    </div>
  )
}
