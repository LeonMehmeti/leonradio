"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, ThumbsUp, ThumbsDown, Volume2, Plus, X, Music } from "lucide-react"
import Link from "next/link"
import { useAudioPlayer } from "@/hooks/useAudioPlayer"
import { stationsConfig } from "@/lib/stations"

interface StationNowPlaying {
  id: string
  data: any
  loading: boolean
  error: string | null
}

export function StickyPlayer() {
  const { isPlaying, currentStation, playStation, stopPlayback } = useAudioPlayer()
  const [isExpanded, setIsExpanded] = useState(false)
  const [stationsNowPlaying, setStationsNowPlaying] = useState<Record<string, StationNowPlaying>>({})

  const stations = Object.values(stationsConfig)

  useEffect(() => {
    // Initialize stationsNowPlaying with loading state
    const initialState: Record<string, StationNowPlaying> = {}
    stations.forEach((station) => {
      initialState[station.id] = {
        id: station.id,
        data: null,
        loading: true,
        error: null,
      }
    })
    setStationsNowPlaying(initialState)

    // Fetch now playing data for each station
    const fetchAllStationsData = async () => {
      const fetchPromises = stations.map(async (station) => {
        try {
          const response = await fetch(station.apiUrl)
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
          }
          const data = await response.json()
          return { id: station.id, data, loading: false, error: null }
        } catch (error) {
          return {
            id: station.id,
            data: null,
            loading: false,
            error: error instanceof Error ? error.message : "Failed to fetch",
          }
        }
      })

      const results = await Promise.all(fetchPromises)
      const newState: Record<string, StationNowPlaying> = {}
      results.forEach((result) => {
        newState[result.id] = result
      })
      setStationsNowPlaying(newState)
    }

    fetchAllStationsData()

    // Set up polling every 30 seconds
    const interval = setInterval(() => {
      fetchAllStationsData()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const togglePlay = (stationId: string) => {
    const station = stationsConfig[stationId as keyof typeof stationsConfig]
    if (station) {
      if (currentStation === stationId && isPlaying) {
        stopPlayback()
      } else {
        playStation(stationId, station.streamUrl)
      }
    }
  }

  // Use the first station as default if no station is playing
  const defaultStation = stations[0]
  const currentStationData = currentStation
    ? stationsConfig[currentStation as keyof typeof stationsConfig]
    : defaultStation
  const currentNowPlaying = currentStation ? stationsNowPlaying[currentStation] : stationsNowPlaying[defaultStation.id]

  // Show default state if no station is playing
  const displayStation = currentStation || defaultStation.id
  const displayStationData = currentStationData

  return (
    <div className="fixed top-0 left-0 right-0 z-50">
      {/* Main Player Bar */}
      <div className="h-16 flex items-center px-4 shadow-lg" style={{ backgroundColor: displayStationData.color }}>
        {/* Play Button */}
        <Button
          onClick={() => togglePlay(displayStation)}
          className="bg-white/20 hover:bg-white/30 text-white border-none mr-4"
          size="icon"
        >
          {currentStation === displayStation && isPlaying ? (
            <Pause className="h-5 w-5" />
          ) : (
            <Play className="h-5 w-5" />
          )}
        </Button>

        {/* Album Art and Song Info */}
        <div className="flex items-center space-x-3 flex-grow">
          <div className="w-10 h-10 rounded-lg overflow-hidden bg-black/20 flex items-center justify-center">
            {currentNowPlaying?.data?.now_playing?.song?.art ? (
              <img
                src={currentNowPlaying.data.now_playing.song.art || "/placeholder.svg"}
                alt="Album cover"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = "none"
                  e.currentTarget.nextElementSibling?.classList.remove("hidden")
                }}
              />
            ) : null}
            <Music
              className={`h-5 w-5 text-white ${currentNowPlaying?.data?.now_playing?.song?.art ? "hidden" : ""}`}
            />
          </div>
          <div className="text-white min-w-0">
            <p className="font-semibold text-sm truncate">
              {currentStation
                ? currentNowPlaying?.data?.now_playing?.song?.title || "Loading..."
                : currentNowPlaying?.data?.now_playing?.song?.title || "Click play to start listening"}
            </p>
            <p className="text-white/80 text-xs truncate">
              {currentStation
                ? currentNowPlaying?.data?.now_playing?.song?.artist || ""
                : currentNowPlaying?.data?.now_playing?.song?.artist || displayStationData.name}
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-2 mr-4">
          <Button className="bg-white/20 hover:bg-white/30 text-white border-none" size="icon">
            <ThumbsUp className="h-4 w-4" />
          </Button>
          <Button className="bg-white/20 hover:bg-white/30 text-white border-none" size="icon">
            <ThumbsDown className="h-4 w-4" />
          </Button>
          <Button className="bg-white/20 hover:bg-white/30 text-white border-none" size="icon">
            <Volume2 className="h-4 w-4" />
          </Button>
        </div>

        {/* Station Logo */}
        <Link href={`/station/${displayStation}`} className="mr-4">
          {displayStationData.logoUrl ? (
            <img
              src={displayStationData.logoUrl || "/placeholder.svg"}
              alt={`${displayStationData.name} logo`}
              className="h-8 w-auto object-contain"
              onError={(e) => {
                e.currentTarget.style.display = "none"
                e.currentTarget.nextElementSibling?.classList.remove("hidden")
              }}
            />
          ) : (
            <div className="text-white font-bold text-sm">{displayStationData.name}</div>
          )}
        </Link>

        {/* Expand/Collapse Button */}
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          className="bg-white/20 hover:bg-white/30 text-white border-none"
          size="icon"
        >
          {isExpanded ? <X className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
        </Button>
      </div>

      {/* Expanded Station List */}
      {isExpanded && (
        <div className="bg-black/90 backdrop-blur-sm max-h-96 overflow-y-auto">
          {stations.map((station) => {
            const stationData = stationsNowPlaying[station.id]
            const nowPlaying = stationData?.data?.now_playing
            const isCurrentStation = currentStation === station.id

            return (
              <div
                key={station.id}
                className={`h-16 flex items-center px-4 border-b border-black/10 ${
                  isCurrentStation ? "opacity-50" : "hover:brightness-110 cursor-pointer"
                }`}
                style={{ backgroundColor: station.color }}
                onClick={() => !isCurrentStation && togglePlay(station.id)}
              >
                {/* Play Button */}
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    togglePlay(station.id)
                  }}
                  className="bg-white/20 hover:bg-white/30 text-white border-none mr-4"
                  size="icon"
                >
                  {isCurrentStation && isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>

                {/* Album Art and Song Info */}
                <div className="flex items-center space-x-3 flex-grow">
                  <div className="w-10 h-10 rounded-lg overflow-hidden bg-black/20 flex items-center justify-center">
                    {nowPlaying?.song?.art ? (
                      <img
                        src={nowPlaying.song.art || "/placeholder.svg"}
                        alt="Album cover"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = "none"
                          e.currentTarget.nextElementSibling?.classList.remove("hidden")
                        }}
                      />
                    ) : null}
                    <Music className={`h-5 w-5 text-white ${nowPlaying?.song?.art ? "hidden" : ""}`} />
                  </div>
                  <div className="text-white min-w-0">
                    <p className="font-semibold text-sm truncate">
                      {stationData?.loading ? "Loading..." : nowPlaying?.song?.title || "No song info"}
                    </p>
                    <p className="text-white/80 text-xs truncate">{nowPlaying?.song?.artist || ""}</p>
                  </div>
                </div>

                {/* Station Logo */}
                <Link
                  href={`/station/${station.id}`}
                  onClick={(e) => e.stopPropagation()}
                  className="flex items-center"
                >
                  {station.logoUrl ? (
                    <img
                      src={station.logoUrl || "/placeholder.svg"}
                      alt={`${station.name} logo`}
                      className="h-8 w-auto object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = "none"
                        e.currentTarget.nextElementSibling?.classList.remove("hidden")
                      }}
                    />
                  ) : (
                    <div className="text-white font-bold text-sm">{station.name}</div>
                  )}
                </Link>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
